/* this header file comes from libowfat, http://www.fefe.de/libowfat/ */
#ifndef NDELAY_H
#define NDELAY_H

#ifdef __cplusplus
extern "C" {
#endif

int ndelay_on(int);
int ndelay_off(int);

#ifdef __cplusplus
}
#endif

#endif

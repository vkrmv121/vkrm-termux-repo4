## Homebrew

You can install Delve via HomeBrew with the following command:

```shell
$ brew install delve
```

## Other installation methods

See [general install instructions](../README.md).

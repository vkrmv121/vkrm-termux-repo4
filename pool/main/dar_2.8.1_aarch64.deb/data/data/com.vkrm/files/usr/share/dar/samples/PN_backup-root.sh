#!/data/data/com.vkrm/files/usr/bin/bash

dar -c "/mnt/storage/backup/root_$(date +%Y-%m-%d-%H%M%S)" -B /root/backup-root.options

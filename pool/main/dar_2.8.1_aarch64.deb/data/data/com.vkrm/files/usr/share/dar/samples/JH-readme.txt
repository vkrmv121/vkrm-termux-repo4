The script makes a backup of user's $HOME, either full of incremental, not compressing compressed files & compressed media and skipping some unimportant directories such as ~/Trash. The darrc is to be in /etc/darrc, dar_archiver.options is used by the script. The script has a part 'OPTIONS TO MODIFY' that shall be altered for customization.
 Regards,
    Jakub Holy 

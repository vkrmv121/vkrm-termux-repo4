/*
* Copyright 2024 Axel Waggershauser
*/
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include "Barcode.h"

#pragma message("Header `Result.h` is deprecated, please include `Barcode.h` and use the new name `Barcode`.")

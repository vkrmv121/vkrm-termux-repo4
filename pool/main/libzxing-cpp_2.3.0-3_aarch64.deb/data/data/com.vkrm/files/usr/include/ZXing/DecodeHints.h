/*
* Copyright 2023 Axel Waggershauser
*/
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include "ReaderOptions.h"

// TODO: remove this backward compatibility header once the deprecated name DecodeHints has been removed (3.0)

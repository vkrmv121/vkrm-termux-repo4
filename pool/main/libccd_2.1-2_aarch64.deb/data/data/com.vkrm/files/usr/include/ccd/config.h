#ifndef __CCD_CONFIG_H__
#define __CCD_CONFIG_H__

/* #undef CCD_SINGLE */
#define CCD_DOUBLE

#endif /* __CCD_CONFIG_H__ */

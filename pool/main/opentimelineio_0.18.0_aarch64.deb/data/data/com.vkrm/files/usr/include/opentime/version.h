// SPDX-License-Identifier: Apache-2.0
// Copyright Contributors to the OpenTimelineIO project

#pragma once

#define OPENTIME_VERSION_MAJOR 0
#define OPENTIME_VERSION_MINOR 18
#define OPENTIME_VERSION_PATCH 0
#define OPENTIME_VERSION v0_18_0

namespace opentime {
namespace OPENTIME_VERSION {
}

using namespace OPENTIME_VERSION;
} // namespace opentime

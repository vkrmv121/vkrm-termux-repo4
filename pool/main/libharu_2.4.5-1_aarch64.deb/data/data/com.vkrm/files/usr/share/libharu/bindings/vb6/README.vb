To use this interface, built Haru as a shared-library (DLL) or use binary 
This is an interface for VB6.
This program was contributed by Ko, Chi-Chih.

To use this interface, build Haru as a shared-library (DLL) or use binary 
package for win32(libharu_x_x_x_dll_win32.zip).

Because I don't have Visual Basic, I did not test this interface. If you have 
any question or suggestion about this interface, please post it to the forum 
of libharu (http://sourceforge.net/forum/?group_id=83044).

